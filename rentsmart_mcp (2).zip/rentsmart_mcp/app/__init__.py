"""Top‑level package for the RentSmart MCP.

This file allows `app` to be recognised as a Python package.  All FastAPI
endpoints are defined in `app/main.py`.
"""

__all__ = []